bash
# Create and activate a conda environment
conda create -n umuzi-nlp python=3.11 -y
conda activate umuzi-nlp

# Install the required libraries
pip install pandas numpy nltk spacy scikit-learn matplotlib seaborn wordcloud jupyter
python -m spacy download en_core_web_sm

bash
code .
